package com.cl.user.servicei;

public interface UserService {
	public String sayHello();

}
